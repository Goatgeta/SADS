from tkinter import *
import pymongo

from pymongo import collection
root = Tk()

# size - OUTER BOX Design
root.geometry("500x500")
root.title("My First GUI")
root.config(bg="white")
namev=StringVar()
roll_no=StringVar()

def sub():
    client=pymongo.MongoClient("mongodb://localhost:27017/")
    db=client['gui']
    collection=db["Priyanshu"]
    dic={
        'name':namev.get(),
        'roll_no':roll_no.get()
    }
    collection.insert_one(dic)
    

head = Label(text="My First GUI", font=("Roboto Mono", 15), bg="white", fg="red")
head.place(x=190, y=25)

# name
name_label = Label(text="Name", font=("Roboto Mono", 12), bg="white", fg="black")
name_label.place(x=20, y=50)
name_entry = Entry(font=("Roboto Mono", 12), text=namev, borderwidth=1, width=25)
name_entry.place(x=20, y=75)

# Roll No
roll_no_label = Label(text="Enter Roll No", font=("Roboto Mono", 12), bg="white", fg="black")
roll_no_label.place(x=20, y=125)
roll_no_entry = Entry(font=("Roboto Mono", 12),text=roll_no, borderwidth=1, width=25)
roll_no_entry.place(x=20, y=150)

# button
submit_button = Button(text="SUBMIT", font=("Roboto Mono", 12),command=sub)
submit_button.place(x=150, y=250)

root.mainloop()
